/*  */
let titles = {
    inMovie:"正在热映",
    comeMovie:"即将上映",
    topMovie:"top250",
}

module.exports = {
    titles
}