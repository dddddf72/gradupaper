// app.js
App({
  onLaunch() {
    wx.setStorageSync('states', null)
  }
})
