import Page from '../../common/page';

Page({
  data: {
    text: '在代码阅读过程中人们说脏话的频率是衡量代码质量的唯一标准。',
    shortText: '技术是开发它的人的共同灵魂。',
  },
});
